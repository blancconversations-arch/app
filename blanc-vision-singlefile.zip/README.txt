BLANC VISION — Single File Build

This is a single `index.html` file (no npm, no Vite, no backend).

What works:
- Camera (HTTPS required)
- Location (HTTPS required)
- Elevation (Open-Meteo)
- Air quality PM2.5 (Open-Meteo)
- Predator-style modes (NORMAL / NIGHT / THERM / EDGE)
- GRID + scanline + vignette + crosshair
- CIVIC layer = on-device 'density' proxy (edge complexity), no external APIs or rate limits

Deploy free (fastest):
1) Create a GitHub repo
2) Upload `index.html` at repo root
3) Settings → Pages → Deploy from branch → main / root
4) Open the generated https://... URL

Or drop `index.html` into Netlify/Vercel as a static site.

