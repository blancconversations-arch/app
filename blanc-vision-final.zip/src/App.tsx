
import { useEffect, useRef, useState } from "react";

export default function App() {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [alt, setAlt] = useState<string>("...");
  const [air, setAir] = useState<string>("...");

  useEffect(() => {
    navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
      if (videoRef.current) videoRef.current.srcObject = stream;
    });

    navigator.geolocation.getCurrentPosition(async pos => {
      const lat = pos.coords.latitude;
      const lon = pos.coords.longitude;

      // Elevation (Open-Meteo)
      const elev = await fetch(
        `https://api.open-meteo.com/v1/elevation?latitude=${lat}&longitude=${lon}`
      ).then(r => r.json());
      setAlt(elev.elevation?.[0] + " m");

      // Air Quality (Open-Meteo)
      const airq = await fetch(
        `https://air-quality-api.open-meteo.com/v1/air-quality?latitude=${lat}&longitude=${lon}&hourly=pm2_5`
      ).then(r => r.json());

      const pm = airq.hourly?.pm2_5?.[0];
      setAir(pm ? pm + " µg/m³" : "...");
    });
  }, []);

  return (
    <div style={{ position: "relative", height: "100vh", overflow: "hidden" }}>
      <video
        ref={videoRef}
        autoPlay
        playsInline
        muted
        style={{
          position: "absolute",
          inset: 0,
          width: "100%",
          height: "100%",
          objectFit: "cover",
          filter: "contrast(1.3) saturate(1.2)"
        }}
      />

      <div
        style={{
          position: "absolute",
          inset: 0,
          background:
            "radial-gradient(circle at center, rgba(0,0,0,0.1), rgba(0,0,0,0.75))",
          pointerEvents: "none"
        }}
      />

      <div
        style={{
          position: "absolute",
          top: 20,
          left: 20,
          color: "white",
          fontFamily: "monospace",
          fontSize: 14,
          letterSpacing: "0.15em"
        }}
      >
        BLANC VISION
        <div style={{ marginTop: 10 }}>ALT {alt}</div>
        <div>AIR {air}</div>
      </div>
    </div>
  );
}
